#!/bin/bash
sudo cp *.php  /var/www/html/hf_ch0x/
