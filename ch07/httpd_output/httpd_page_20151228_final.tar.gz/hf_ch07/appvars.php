<?php
  // Define application constants
  define('MM_UPLOADPATH', 'images/');
  define('MM_MAXFILESIZE', 32768);      // 32 KB
  define('MM_MAXIMGWIDTH', 120);        // 120 pixels
  define('MM_MAXIMGHEIGHT', 120);       // 120 pixels
  define('MM_HOME_URL','http://'.$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF']).'/index.php');
?>
