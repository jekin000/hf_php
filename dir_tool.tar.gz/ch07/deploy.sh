#!/bin/bash
sudo cp xxx.php  /var/www/html/hf_chxx/
