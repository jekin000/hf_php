sudo cp -R /var/www/html/hf_chxx/ ./
tar -zcvf httpd_page_2016xxxx.tar.gz hf_chxx/

