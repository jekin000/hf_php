<?php
    define('DB_HST','localhost');
    define('DB_USR','root');
    define('DB_PWD','root');
    define('DB_NAM','guitarwars');
?>
