<?php
    define('GW_UPLOADPATH','images/');
    define('GW_MAXFILESIZE',32768);
?>

