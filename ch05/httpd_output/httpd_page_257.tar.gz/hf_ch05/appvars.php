<?php
    define('GW_UPLOADPATH','images/');
?>

